import os

org_PATH = "/home2/thinhvu/NLP/matchsum/MatchSum/data/original_val_CNNDM_bert.jsonl"
mod_PATH = "/home2/thinhvu/NLP/matchsum/MatchSum/data/val_CNNDM_bert.jsonl"

#open the file
orginal_text_file = open(org_PATH,'r')
modified_text_file = open(mod_PATH,'w')

#get the list of line
line_list = orginal_text_file.readlines()
print(len(line_list))

#for each line from 0 to 13707, write to mod_path
for i in range (0,1957):
    modified_text_file.writelines(line_list[i])

#close the file
orginal_text_file.close()
modified_text_file.close() 

