import subprocess
import sys

def install(package):
    subprocess.check_call([sys.executable, "-m", "pip", "install", package])

list = ["torch==1.4.0","fastNLP==0.5.0","pyrouge==0.1.3","rouge==1.0.0","transformers==2.5.1"]
for i in range (0,1000):    
    for pack in list:
        install(pack)
