import os
from glob import glob
import  json
import py_vncorenlp

py_vncorenlp.download_model(save_dir='/home2/thinhvu/NLP/matchsum/MatchSum/tools/py_vncorenlp')
rdrsegmenter = py_vncorenlp.VnCoreNLP(annotators=["wseg"], save_dir='/home2/thinhvu/NLP/matchsum/MatchSum/tools/py_vncorenlp')


BASE_HOME='/home2/thinhvu/NLP/matchsum/MatchSum/tools/Wikilingual'
IN_HOME=os.path.join(BASE_HOME,'1_tsv_files')
OUT_HOME=os.path.join(BASE_HOME,'2_jsonl_files')

def ParagraphToLines(inputText):
    return(rdrsegmenter.word_segment(inputText))
        

# all_in_ps=glob(os.path.join(IN_HOME,'*'))
all_in_ps = ['/home2/thinhvu/NLP/matchsum/MatchSum/tools/Wikilingual/1_tsv_files/test.tsv', '/home2/thinhvu/NLP/matchsum/MatchSum/tools/Wikilingual/1_tsv_files/val.tsv']
i=0
for p in all_in_ps:
    ss_all_s=[]
    with open(p) as f:
        for s_o in f:
            # s_n={'article_id':str(i)}
            s_n = {}
            s_o = s_o.strip().split('\t')
            s_n['text']=ParagraphToLines(s_o[0])
            s_n['summary']= ParagraphToLines(s_o[1])
            ss_all_s.append(s_n)
            i+=1
            if i%500==0:
                print(i)

    ss=os.path.splitext(os.path.basename(p))[0]
    o_p=os.path.join(OUT_HOME,f'{ss}.jsonl')
    with open(os.path.join(o_p), "w",encoding='utf-8') as wf:
        for inst in ss_all_s:
            wf.write(json.dumps(inst,ensure_ascii=False) + "\n")