# #TRAIN
python get_candidate.py --tokenizer=phobert --data_path=/home2/thinhvu/NLP/matchsum/MatchSum/tools/Wikilingual/2_jsonl_files/train.jsonl --index_path=/home2/thinhvu/NLP/matchsum/MatchSum/tools/Wikilingual/3_index.jsonl_files/train.tsv.index.jsonl --write_path=/home2/thinhvu/NLP/matchsum/MatchSum/tools/backup/train_CNNDM_phobert.jsonl
#VAL
# python get_candida
te.py --tokenizer=phobert --data_path=/home2/thinhvu/NLP/matchsum/MatchSum/tools/Wikilingual/2_jsonl_files/val.jsonl --index_path=/home2/thinhvu/NLP/matchsum/MatchSum/tools/Wikilingual/3_index.jsonl_files/val.tsv.index.jsonl --write_path=/home2/thinhvu/NLP/matchsum/MatchSum/tools/backup/val_CNNDM_phobert.jsonl
# #TEST
# python get_candidate.py --tokenizer=phobert --data_path=/home2/thinhvu/NLP/matchsum/MatchSum/tools/Wikilingual/2_jsonl_files/test.jsonl --index_path=/home2/thinhvu/NLP/matchsum/MatchSum/tools/Wikilingual/3_index.jsonl_files/test.tsv.index.jsonl --write_path=/home2/thinhvu/NLP/matchsum/MatchSumtools/backup/test_CNNDM_phobert.jsonl
##1Val
# python get_candidate.py --tokenizer=phobert --data_path=/home2/thinhvu/NLP/matchsum/MatchSum/tools/Wikilingual/2_jsonl_files/1val.jsonl --index_path=/home2/thinhvu/NLP/matchsum/MatchSum/tools/Wikilingual/3_index.jsonl_files/1val.tsv.index.jsonl --write_path=/home2/thinhvu/NLP/matchsum/MatchSum/tools/backup/1val_CNNDM_phobert.jsonl
